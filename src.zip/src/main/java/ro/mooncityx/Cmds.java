package ro.mooncityx;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;

@Mod.EventBusSubscriber(modid = Main.ID)
public class Cmds {
    static final Map<UUID, BlockPos[]> SEL = new HashMap<>();

    static int fail(CommandContext<CommandSourceStack> c, String m) { c.getSource().sendFailure(Component.literal(m)); return 0; }
    static int ok(CommandContext<CommandSourceStack> c, String m) { c.getSource().sendSuccess(() -> Component.literal(m), false); return 1; }
    static Data D(CommandContext<CommandSourceStack> c) { return Data.get(c.getSource().getServer()); }
    static String s(CommandContext<CommandSourceStack> c, String n) { return StringArgumentType.getString(c, n); }

    @SubscribeEvent
    public static void reg(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        Predicate<CommandSourceStack> op = x -> x.hasPermission(2);

        d.register(Commands.literal("claim").executes(Cmds::claim));
        d.register(Commands.literal("unclaim").executes(Cmds::unclaim));
        d.register(Commands.literal("mdt").executes(Cmds::mdt));

        d.register(Commands.literal("waypoint")
            .then(Commands.literal("clear").executes(Cmds::wpClear))
            .then(Commands.argument("x", IntegerArgumentType.integer())
                .then(Commands.argument("z", IntegerArgumentType.integer()).executes(Cmds::wpSet))));

        d.register(Commands.literal("plot")
            .then(Commands.literal("pos1").requires(op).executes(c -> pos(c, 0)))
            .then(Commands.literal("pos2").requires(op).executes(c -> pos(c, 1)))
            .then(Commands.literal("create").requires(op).then(Commands.argument("name", StringArgumentType.word()).executes(Cmds::plotCreate)))
            .then(Commands.literal("delete").requires(op).then(Commands.argument("name", StringArgumentType.word()).executes(Cmds::plotDelete)))
            .then(Commands.literal("list").executes(Cmds::plotList))
            .then(Commands.literal("add").then(Commands.argument("player", StringArgumentType.word()).executes(c -> member(c, true))))
            .then(Commands.literal("remove").then(Commands.argument("player", StringArgumentType.word()).executes(c -> member(c, false)))));

        d.register(Commands.literal("zone").requires(op)
            .then(Commands.literal("create").then(Commands.argument("name", StringArgumentType.word())
                .then(Commands.argument("type", StringArgumentType.word()).executes(Cmds::zoneCreate))))
            .then(Commands.literal("delete").then(Commands.argument("name", StringArgumentType.word()).executes(Cmds::zoneDelete)))
            .then(Commands.literal("list").executes(Cmds::zoneList)));

        d.register(Commands.literal("mafia").requires(op)
            .then(Commands.literal("create").then(Commands.argument("name", StringArgumentType.word()).executes(c -> { D(c).mafia(s(c, "name")); return ok(c, "Mafie creata."); })))
            .then(Commands.literal("delete").then(Commands.argument("name", StringArgumentType.word()).executes(c -> { D(c).sub("mafia").remove(s(c, "name")); return ok(c, "Mafie stearsa."); })))
            .then(Commands.literal("add").then(Commands.argument("name", StringArgumentType.word()).then(Commands.argument("player", StringArgumentType.word()).executes(c -> mafiaMember(c, true)))))
            .then(Commands.literal("remove").then(Commands.argument("name", StringArgumentType.word()).then(Commands.argument("player", StringArgumentType.word()).executes(c -> mafiaMember(c, false)))))
            .then(Commands.literal("list").executes(c -> {
                Data D = D(c);
                for (String k : D.sub("mafia").getAllKeys()) {
                    StringBuilder sb = new StringBuilder(k + ": ");
                    for (Tag t : D.sub("mafia").getList(k, 8)) sb.append(D.nameOf(t.getAsString())).append(" ");
                    ok(c, sb.toString());
                }
                return 1;
            })));

        d.register(Commands.literal("police").requires(op)
            .then(Commands.literal("add").then(Commands.argument("player", StringArgumentType.word()).executes(c -> police(c, true))))
            .then(Commands.literal("remove").then(Commands.argument("player", StringArgumentType.word()).executes(c -> police(c, false)))));

        d.register(Commands.literal("bank").requires(op)
            .then(Commands.literal("give").then(Commands.argument("player", StringArgumentType.word())
                .then(Commands.argument("amount", LongArgumentType.longArg(1, 1_000_000_000L)).executes(c -> {
                    UUID u = D(c).uuidByName(s(c, "player"));
                    if (u == null) return fail(c, "Jucator necunoscut (trebuie sa fi intrat o data).");
                    D(c).add(u, LongArgumentType.getLong(c, "amount"));
                    return ok(c, "Banii au fost adaugati.");
                }))));
    }

    // ---------- claim ----------
    static int claim(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        Data D = D(c);
        CompoundTag pl = D.plotAt(p.blockPosition().getX(), p.blockPosition().getZ());
        if (pl == null) return fail(c, "Nu esti intr-un plot.");
        if (!pl.getString("o").isEmpty()) return fail(c, "Plotul este deja ocupat.");
        int count = 0;
        for (Tag t : D.list("plots")) if (((CompoundTag) t).getString("o").equals(p.getUUID().toString())) count++;
        if (count >= 2) return fail(c, "Ai deja 2 ploturi.");
        pl.putString("o", p.getUUID().toString());
        D.setDirty();
        int cx = (pl.getInt("x1") + pl.getInt("x2")) / 2, cz = (pl.getInt("z1") + pl.getInt("z2")) / 2;
        Sync.waypoint(p, cx, cz, "Plot " + pl.getString("n"));
        Sync.send(p);
        return ok(c, "Ai revendicat plotul " + pl.getString("n") + ". Waypoint setat.");
    }

    static int unclaim(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        Data D = D(c);
        CompoundTag pl = D.plotAt(p.blockPosition().getX(), p.blockPosition().getZ());
        if (pl == null || !pl.getString("o").equals(p.getUUID().toString())) return fail(c, "Nu esti pe plotul tau.");
        pl.putString("o", "");
        pl.put("m", new ListTag());
        D.setDirty();
        Sync.send(p);
        return ok(c, "Plot eliberat.");
    }

    static int member(CommandContext<CommandSourceStack> c, boolean add) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        Data D = D(c);
        CompoundTag pl = D.plotAt(p.blockPosition().getX(), p.blockPosition().getZ());
        if (pl == null || !pl.getString("o").equals(p.getUUID().toString())) return fail(c, "Trebuie sa stai pe plotul tau.");
        UUID u = D.uuidByName(s(c, "player"));
        if (u == null) return fail(c, "Jucator necunoscut.");
        if (!pl.contains("m", 9)) pl.put("m", new ListTag());
        ListTag m = pl.getList("m", 8);
        String id = u.toString();
        for (int i = m.size() - 1; i >= 0; i--) if (m.getString(i).equals(id)) m.remove(i);
        if (add) m.add(StringTag.valueOf(id));
        D.setDirty();
        return ok(c, add ? "Acces acordat." : "Acces retras.");
    }

    // ---------- selectie regiuni ----------
    static int pos(CommandContext<CommandSourceStack> c, int i) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        SEL.computeIfAbsent(p.getUUID(), k -> new BlockPos[2])[i] = p.blockPosition();
        return ok(c, "Pozitia " + (i + 1) + " setata.");
    }

    static CompoundTag region(CommandContext<CommandSourceStack> c, String name) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        BlockPos[] s = SEL.get(p.getUUID());
        if (s == null || s[0] == null || s[1] == null) return null;
        CompoundTag t = new CompoundTag();
        t.putString("n", name);
        t.putInt("x1", Math.min(s[0].getX(), s[1].getX()));
        t.putInt("x2", Math.max(s[0].getX(), s[1].getX()));
        t.putInt("z1", Math.min(s[0].getZ(), s[1].getZ()));
        t.putInt("z2", Math.max(s[0].getZ(), s[1].getZ()));
        return t;
    }

    static boolean exists(ListTag l, String n) {
        for (Tag t : l) if (((CompoundTag) t).getString("n").equalsIgnoreCase(n)) return true;
        return false;
    }

    static int plotCreate(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        String n = s(c, "name");
        CompoundTag t = region(c, n);
        if (t == null) return fail(c, "Foloseste intai /plot pos1 si /plot pos2.");
        ListTag l = D(c).list("plots");
        if (exists(l, n)) return fail(c, "Exista deja un plot cu numele asta.");
        t.putString("o", "");
        l.add(t);
        return ok(c, "Plot " + n + " creat. Jucatorii pot da /claim in el.");
    }

    static int plotDelete(CommandContext<CommandSourceStack> c) {
        String n = s(c, "name");
        D(c).list("plots").removeIf(t -> ((CompoundTag) t).getString("n").equalsIgnoreCase(n));
        return ok(c, "Plot sters.");
    }

    static int plotList(CommandContext<CommandSourceStack> c) {
        Data D = D(c);
        for (Tag t : D.list("plots")) {
            CompoundTag p = (CompoundTag) t;
            String o = p.getString("o");
            ok(c, p.getString("n") + " (" + p.getInt("x1") + "," + p.getInt("z1") + ") - " + (o.isEmpty() ? "LIBER" : D.nameOf(o)));
        }
        return 1;
    }

    static int zoneCreate(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        String n = s(c, "name"), ty = s(c, "type");
        if (!ty.equals("bad") && !ty.equals("city")) return fail(c, "Tip: bad (zona rau famata) sau city (oras protejat).");
        CompoundTag t = region(c, n);
        if (t == null) return fail(c, "Foloseste intai /plot pos1 si /plot pos2.");
        ListTag l = D(c).list("zones");
        if (exists(l, n)) return fail(c, "Exista deja.");
        t.putString("t", ty);
        l.add(t);
        return ok(c, "Zona " + n + " (" + ty + ") creata.");
    }

    static int zoneDelete(CommandContext<CommandSourceStack> c) {
        String n = s(c, "name");
        D(c).list("zones").removeIf(t -> ((CompoundTag) t).getString("n").equalsIgnoreCase(n));
        return ok(c, "Zona stearsa.");
    }

    static int zoneList(CommandContext<CommandSourceStack> c) {
        for (Tag t : D(c).list("zones")) {
            CompoundTag z = (CompoundTag) t;
            ok(c, z.getString("n") + " [" + z.getString("t") + "]");
        }
        return 1;
    }

    // ---------- diverse ----------
    static int mafiaMember(CommandContext<CommandSourceStack> c, boolean add) {
        Data D = D(c);
        UUID u = D.uuidByName(s(c, "player"));
        if (u == null) return fail(c, "Jucator necunoscut.");
        if (!D.sub("mafia").contains(s(c, "name"), 9)) return fail(c, "Mafie inexistenta.");
        ListTag m = D.mafia(s(c, "name"));
        String id = u.toString();
        for (int i = m.size() - 1; i >= 0; i--) if (m.getString(i).equals(id)) m.remove(i);
        if (add) m.add(StringTag.valueOf(id));
        return ok(c, add ? "Adaugat in mafie." : "Scos din mafie.");
    }

    static int police(CommandContext<CommandSourceStack> c, boolean add) {
        Data D = D(c);
        UUID u = D.uuidByName(s(c, "player"));
        if (u == null) return fail(c, "Jucator necunoscut.");
        if (add) D.sub("police").putBoolean(u.toString(), true); else D.sub("police").remove(u.toString());
        return ok(c, add ? "Politist adaugat." : "Politist scos.");
    }

    static int mdt(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        if (!Actions.isPolice(p)) return fail(c, "Doar politia.");
        Sync.send(p);
        Net.toPlayer(p, "open", Util.tag("s", "mdt"));
        return 1;
    }

    static int wpSet(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        Sync.waypoint(p, IntegerArgumentType.getInteger(c, "x"), IntegerArgumentType.getInteger(c, "z"), "Waypoint");
        return 1;
    }

    static int wpClear(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        Net.toPlayer(p, "wp", Util.tag("clear", "1"));
        return 1;
    }
}
