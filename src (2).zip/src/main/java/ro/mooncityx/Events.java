package ro.mooncityx;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Main.ID)
public class Events {
    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            Data.get(sp.server).touch(sp);
            Sync.send(sp);
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase == TickEvent.Phase.END && e.side.isServer() && e.player instanceof ServerPlayer sp && sp.tickCount % 40 == 0) {
            Sync.send(sp);
        }
    }

    @SubscribeEvent
    public static void brk(BlockEvent.BreakEvent e) {
        Player p = e.getPlayer();
        if (!(p instanceof ServerPlayer sp)) return;
        if (!Protect.canBuild(sp, e.getPos(), true)) {
            e.setCanceled(true);
            sp.displayClientMessage(Component.literal("\u00a7cZona protejata."), true);
            return;
        }
        Jobs.onBreak(sp, e.getState());
    }

    @SubscribeEvent
    public static void place(BlockEvent.EntityPlaceEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (!Protect.canBuild(sp, e.getPos(), true)) {
            e.setCanceled(true);
            sp.displayClientMessage(Component.literal("\u00a7cZona protejata."), true);
            return;
        }
        Jobs.onPlace(sp, e.getPos());
    }

    @SubscribeEvent
    public static void click(PlayerInteractEvent.RightClickBlock e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        // doar ploturi (usi/cufere); strada ramane libera
        if (!Protect.canBuild(sp, e.getPos(), false)) {
            e.setCanceled(true);
            sp.displayClientMessage(Component.literal("\u00a7cPlot privat."), true);
        }
    }

    @SubscribeEvent
    public static void boom(ExplosionEvent.Detonate e) {
        MinecraftServer s = e.getLevel().getServer();
        if (s == null) return;
        Data D = Data.get(s);
        e.getAffectedBlocks().removeIf(pos -> D.plotAt(pos.getX(), pos.getZ()) != null || D.zoneAt(pos.getX(), pos.getZ(), "city") != null);
    }
}
