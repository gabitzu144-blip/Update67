package ro.mooncityx.client;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;

import java.util.ArrayList;
import java.util.List;

public class ClientState {
    public static long bal;
    public static String iban = "", job = "none", wanted = "", wpName = "", callState = "idle", callOther = "";
    public static int xp, wpx, wpz;
    public static boolean hasWp, police;
    public static CompoundTag contract = new CompoundTag();
    public static ListTag zones = new ListTag(), plots = new ListTag();
    public static List<String> inbox = new ArrayList<>(), mdt = new ArrayList<>();
    public static float speed;
    public static boolean inVehicle;
    public static String vehName = "";
}
