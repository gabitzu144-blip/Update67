package ro.mooncityx.client;

import net.minecraft.client.Minecraft;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import ro.mooncityx.Util;

/** Reda audio YouTube folosind yt-dlp + ffmpeg instalate pe calculatorul jucatorului. */
public class Audio {
    static class Track {
        volatile Clip clip;
        volatile boolean dead, paused;
        volatile Process proc;
        double x, y, z;
        float vol;
        Path dir;
    }

    static final Map<String, Track> T = new ConcurrentHashMap<>();

    public static void play(String id, String url, double x, double y, double z, float vol) {
        stop(id);
        if (!Util.YT.matcher(url).matches()) return;
        Track t = new Track();
        t.x = x; t.y = y; t.z = z; t.vol = vol;
        T.put(id, t);
        Thread th = new Thread(() -> run(t, url), "mcx-audio");
        th.setDaemon(true);
        th.start();
    }

    static void run(Track t, String url) {
        try {
            t.dir = Files.createTempDirectory("mcxaudio");
            ProcessBuilder pb = new ProcessBuilder("yt-dlp", "-x", "--audio-format", "wav", "--no-playlist",
                "-o", t.dir.resolve("a.%(ext)s").toString(), "--", url);
            pb.redirectErrorStream(true);
            pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
            t.proc = pb.start();
            if (!t.proc.waitFor(180, TimeUnit.SECONDS)) { t.proc.destroyForcibly(); return; }
            if (t.dead) return;
            Path f = t.dir.resolve("a.wav");
            if (!Files.exists(f)) return;
            AudioInputStream in = AudioSystem.getAudioInputStream(f.toFile());
            Clip c = AudioSystem.getClip();
            c.open(in);
            t.clip = c;
            update(t);
            if (t.dead) { c.close(); return; }
            c.loop(Clip.LOOP_CONTINUOUSLY);
        } catch (Exception ignored) {
        }
    }

    static void update(Track t) {
        Clip c = t.clip;
        Minecraft mc = Minecraft.getInstance();
        if (c == null || mc.player == null) return;
        double dist = Math.sqrt(mc.player.distanceToSqr(t.x, t.y, t.z));
        float att = (float) Math.max(0.0, 1.0 - dist / 48.0);
        try {
            FloatControl g = (FloatControl) c.getControl(FloatControl.Type.MASTER_GAIN);
            float db = (float) (20.0 * Math.log10(Math.max(0.0001, t.vol * att)));
            g.setValue(Math.max(g.getMinimum(), Math.min(g.getMaximum(), db)));
        } catch (Exception ignored) {
        }
    }

    public static void tick() {
        for (Track t : T.values()) update(t);
    }

    public static void pause(String id) {
        Track t = T.get(id);
        if (t == null || t.clip == null) return;
        t.paused = !t.paused;
        if (t.paused) t.clip.stop(); else t.clip.loop(Clip.LOOP_CONTINUOUSLY);
    }

    public static void stop(String id) {
        Track t = T.remove(id);
        if (t == null) return;
        t.dead = true;
        try { if (t.proc != null) t.proc.destroyForcibly(); } catch (Exception ignored) {}
        try { if (t.clip != null) { t.clip.stop(); t.clip.close(); } } catch (Exception ignored) {}
        try {
            if (t.dir != null) {
                try (var s = Files.list(t.dir)) { s.forEach(p -> p.toFile().delete()); }
                Files.deleteIfExists(t.dir);
            }
        } catch (Exception ignored) {}
    }

    public static void stopAll() {
        for (String k : T.keySet()) stop(k);
    }
}
