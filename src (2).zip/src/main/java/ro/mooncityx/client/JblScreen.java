package ro.mooncityx.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import ro.mooncityx.Net;
import ro.mooncityx.Util;

public class JblScreen extends Screen {
    static final int W = 260, H = 170;
    static double vol = 0.5;
    int L, T;
    EditBox url;

    public JblScreen() { super(Component.literal("JBL")); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void init() {
        L = (width - W) / 2;
        T = (height - H) / 2;
        url = new EditBox(font, L + 12, T + 44, W - 24, 18, Component.literal("Link YouTube"));
        url.setMaxLength(200);
        url.setHint(Component.literal("https://www.youtube.com/watch?v=..."));
        addRenderableWidget(url);

        addRenderableWidget(new AbstractSliderButton(L + 12, T + 76, W - 24, 18, Component.literal("Volum: " + (int) (vol * 100) + "%"), vol) {
            @Override protected void updateMessage() { setMessage(Component.literal("Volum: " + (int) (value * 100) + "%")); }
            @Override protected void applyValue() { vol = value; }
        });

        addRenderableWidget(Button.builder(Component.literal("PLAY"), b ->
            Net.toServer("jbl_play", Util.tag("url", url.getValue().trim(), "vol", String.valueOf((float) vol)))).bounds(L + 12, T + 104, 74, 20).build());
        addRenderableWidget(Button.builder(Component.literal("PAUZA"), b ->
            Net.toServer("jbl_pause", new CompoundTag())).bounds(L + 93, T + 104, 74, 20).build());
        addRenderableWidget(Button.builder(Component.literal("OPRESTE"), b ->
            Net.toServer("jbl_stop", new CompoundTag())).bounds(L + 174, T + 104, 74, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.fill(L - 2, T - 2, L + W + 2, T + H + 2, 0xFFFFC107);
        g.fill(L, T, L + W, T + H, 0xFF101426);
        g.drawString(font, "BOXA PORTABILA JBL", L + 12, T + 10, 0xFFFFFFFF, false);
        g.drawString(font, "AUDIO 3D YOUTUBE STREAMING", L + 12, T + 22, 0xFFFFC107, false);
        g.drawString(font, "LINK PIESA YOUTUBE", L + 12, T + 34, 0xFF9999BB, false);
        g.drawString(font, "Muzica se aude 3D in jurul tau (raza 48 blocuri)", L + 12, T + 134, 0xFF777799, false);
        g.drawString(font, "Fiecare jucator are nevoie de yt-dlp + ffmpeg", L + 12, T + 148, 0xFF777799, false);
        super.render(g, mx, my, pt);
    }
}
