package ro.mooncityx.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import ro.mooncityx.Net;
import ro.mooncityx.Util;

public class MdtScreen extends Screen {
    static final int W = 380, H = 230;
    int L, T, tab = 0;
    EditBox[] f = new EditBox[3];
    static final String[] NAMES = {"Acasa", "Cautare", "Wanted", "Mafii", "Amenzi"};

    public MdtScreen() { super(Component.literal("MDT")); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void init() {
        L = (width - W) / 2;
        T = (height - H) / 2;
        Net.toServer("sync", new CompoundTag());
        rebuild();
    }

    Button btn(String s, int x, int y, int w, Runnable r) {
        Button b = Button.builder(Component.literal(s), bb -> r.run()).bounds(x, y, w, 18).build();
        addRenderableWidget(b);
        return b;
    }

    EditBox box(int i, int y, String hint, int max) {
        EditBox b = new EditBox(font, L + 104, y, 200, 16, Component.literal(hint));
        b.setMaxLength(max);
        b.setHint(Component.literal(hint));
        addRenderableWidget(b);
        f[i] = b;
        return b;
    }

    void go(int t) {
        tab = t;
        ClientState.mdt = new java.util.ArrayList<>();
        if (t == 3) Net.toServer("mdt_mafias", new CompoundTag());
        rebuild();
    }

    String v(int i) { return f[i] == null ? "" : f[i].getValue(); }

    void rebuild() {
        clearWidgets();
        f = new EditBox[3];
        for (int i = 0; i < NAMES.length; i++) {
            final int t = i;
            btn((t == tab ? "> " : "") + NAMES[i], L + 10, T + 54 + i * 24, 84, () -> go(t));
        }
        switch (tab) {
            case 1 -> {
                box(0, T + 56, "Nume jucator", 16);
                btn("Cauta", L + 310, T + 55, 56, () -> Net.toServer("mdt_search", Util.tag("name", v(0))));
            }
            case 2 -> {
                box(0, T + 56, "Nume jucator", 16);
                box(1, T + 80, "Motiv (gol = sterge wanted)", 60);
                btn("Seteaza", L + 104, T + 104, 98, () -> Net.toServer("mdt_wanted", Util.tag("name", v(0), "reason", v(1))));
            }
            case 4 -> {
                box(0, T + 56, "Nume jucator", 16);
                box(1, T + 80, "Suma ($)", 6);
                box(2, T + 104, "Motiv", 40);
                btn("Da amenda", L + 104, T + 128, 98, () -> Net.toServer("mdt_fine", Util.tag("name", v(0), "amt", v(1), "reason", v(2))));
            }
            default -> { }
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.fill(L - 2, T - 2, L + W + 2, T + H + 2, 0xFF2A5CFF);
        g.fill(L, T, L + W, T + H, 0xFF08122E);
        g.fill(L + 6, T + 48, L + 98, T + H - 6, 0xFF0C1A44);
        g.drawString(font, Component.literal("MDT MOONCITY").withStyle(net.minecraft.ChatFormatting.BOLD, net.minecraft.ChatFormatting.ITALIC), L + 12, T + 10, 0xFFFFFFFF, false);
        g.drawString(font, NAMES[tab], L + 12, T + 26, 0xFF5C8CFF, false);
        g.drawString(font, "POLITIA", L + W - 60, T + 10, 0xFFFFD34D, false);

        int y = T + 56;
        if (tab == 0) {
            g.drawString(font, "Bine ai venit, agent.", L + 104, y, 0xFFFFFFFF, false);
            g.drawString(font, "Cautare = date jucator | Wanted = urmarit", L + 104, y + 14, 0xFF9999BB, false);
            g.drawString(font, "Mafii = lista grupari | Amenzi = sanctiuni", L + 104, y + 26, 0xFF9999BB, false);
            g.drawString(font, "Admin: /mafia create/add/remove, /police add", L + 104, y + 44, 0xFF777799, false);
        } else {
            int start = tab == 1 ? T + 82 : tab == 2 ? T + 130 : tab == 4 ? T + 156 : T + 56;
            for (int i = 0; i < ClientState.mdt.size() && i < 10; i++)
                g.drawString(font, font.plainSubstrByWidth(ClientState.mdt.get(i), W - 114), L + 104, start + i * 12, 0xFFDDDDFF, false);
        }
        super.render(g, mx, my, pt);
    }
}
