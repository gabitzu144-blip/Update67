package ro.mooncityx.client;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import ro.mooncityx.Main;

@Mod.EventBusSubscriber(modid = Main.ID, value = Dist.CLIENT)
public class ClientEvents {
    static Vec3 last;
    static int n;

    static void reset() {
        last = null;
        ClientState.speed = 0;
        ClientState.inVehicle = false;
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { reset(); return; }
        if (mc.isPaused()) return;

        // vitezometru: orice entitate de vehicul din alt mod (Vehicle, Immersive Vehicles etc.)
        Entity v = mc.player.getVehicle();
        if (v != null) {
            ResourceLocation k = ForgeRegistries.ENTITY_TYPES.getKey(v.getType());
            if (k != null && !k.getNamespace().equals("minecraft")) {
                Vec3 p = v.position();
                if (last != null) {
                    double inst = p.distanceTo(last) * 72.0; // blocuri/tick -> km/h
                    ClientState.speed = (float) (ClientState.speed * 0.6 + inst * 0.4);
                }
                last = p;
                ClientState.inVehicle = true;
                ClientState.vehName = k.getPath();
            } else reset();
        } else reset();

        if (++n % 5 == 0) Audio.tick();
    }

    @SubscribeEvent
    public static void logout(ClientPlayerNetworkEvent.LoggingOut e) {
        Audio.stopAll();
        ClientState.callState = "idle";
        ClientState.hasWp = false;
    }
}
