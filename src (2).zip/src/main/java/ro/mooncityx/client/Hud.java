package ro.mooncityx.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import ro.mooncityx.Util;

public class Hud {
    static void rect(GuiGraphics g, CompoundTag c, double px, double pz, double sc, int x0, int y0, int S, int col) {
        int cx = x0 + S / 2, cy = y0 + S / 2;
        int l = (int) Math.round(cx + (c.getInt("x1") - px) * sc);
        int r = (int) Math.round(cx + (c.getInt("x2") + 1 - px) * sc);
        int t = (int) Math.round(cy + (c.getInt("z1") - pz) * sc);
        int b = (int) Math.round(cy + (c.getInt("z2") + 1 - pz) * sc);
        l = Math.max(l, x0); r = Math.min(r, x0 + S); t = Math.max(t, y0); b = Math.min(b, y0 + S);
        if (l < r && t < b) g.fill(l, t, r, b, col);
    }

    public static void render(ForgeGui gui, GuiGraphics g, float pt, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Font f = mc.font;
        double px = mc.player.getX(), pz = mc.player.getZ();

        // ---------------- minimap (dreapta sus) ----------------
        int S = 96, x0 = w - S - 8, y0 = 8, cx = x0 + S / 2, cy = y0 + S / 2;
        double sc = (S / 2.0) / 110.0; // raza 110 blocuri
        g.fill(x0 - 2, y0 - 2, x0 + S + 2, y0 + S + 2, 0xFF6C4DFF);
        g.fill(x0, y0, x0 + S, y0 + S, 0xE00A0A1E);
        for (Tag t : ClientState.zones) {
            CompoundTag c = (CompoundTag) t;
            rect(g, c, px, pz, sc, x0, y0, S, c.getString("t").equals("bad") ? 0xAAFF2020 : 0x554488FF);
        }
        for (Tag t : ClientState.plots) {
            CompoundTag c = (CompoundTag) t;
            int col = c.getBoolean("mine") ? 0xAA00E5A0 : c.getString("on").isEmpty() ? 0x88888888 : 0x88FFC800;
            rect(g, c, px, pz, sc, x0, y0, S, col);
        }
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);
        g.drawString(f, "N", cx - 2, y0 + 1, 0xFFFFFFFF, true);

        int textY = y0 + S + 5;
        if (ClientState.hasWp) {
            double dx = ClientState.wpx + 0.5 - px, dz = ClientState.wpz + 0.5 - pz;
            double dist = Math.sqrt(dx * dx + dz * dz);
            double ex = dx * sc, ey = dz * sc;
            double m = Math.max(Math.abs(ex), Math.abs(ey)), lim = S / 2.0 - 3;
            if (m > lim) { ex *= lim / m; ey *= lim / m; }
            int steps = (int) Math.max(Math.abs(ex), Math.abs(ey));
            for (int i = 1; i < steps; i++) {
                g.fill(cx + (int) Math.round(ex * i / steps), cy + (int) Math.round(ey * i / steps),
                    cx + (int) Math.round(ex * i / steps) + 1, cy + (int) Math.round(ey * i / steps) + 1, 0xFFFFE066);
            }
            int mx = cx + (int) Math.round(ex), my = cy + (int) Math.round(ey);
            g.fill(mx - 2, my - 2, mx + 3, my + 3, 0xFFFF3B3B);
            String ds = dist >= 1000 ? String.format("%.2f km", dist / 1000.0) : (int) dist + " m";
            String txt = ClientState.wpName + ": " + ds;
            g.drawString(f, txt, x0 + S - f.width(txt), textY, 0xFFFFE066, true);
            textY += 11;
        }
        String bal = "$" + Util.fmt(ClientState.bal);
        g.drawString(f, bal, x0 + S - f.width(bal), textY, 0xFF7CFFB0, true);
        textY += 11;
        if (ClientState.contract.contains("t")) {
            String c = "Contract: " + ClientState.contract.getInt("d") + "/" + ClientState.contract.getInt("t");
            g.drawString(f, c, x0 + S - f.width(c), textY, 0xFFFFC857, true);
        }

        // ---------------- zona periculoasa ----------------
        int bx = (int) Math.floor(px), bz = (int) Math.floor(pz);
        for (Tag t : ClientState.zones) {
            CompoundTag c = (CompoundTag) t;
            if (c.getString("t").equals("bad") && bx >= c.getInt("x1") && bx <= c.getInt("x2") && bz >= c.getInt("z1") && bz <= c.getInt("z2")) {
                if ((System.currentTimeMillis() / 500) % 2 == 0) {
                    String s = "ZONA PERICULOASA: " + c.getString("n");
                    g.drawString(f, s, (w - f.width(s)) / 2, 24, 0xFFFF4040, true);
                }
                break;
            }
        }

        // ---------------- vitezometru ----------------
        if (ClientState.inVehicle) {
            int vcx = w - 70, vcy = h - 62, r = 44;
            float max = 240f;
            float frac = Math.min(1f, ClientState.speed / max);
            int N = 54;
            g.fill(vcx - r - 8, vcy - r - 8, vcx + r + 8, vcy + r + 14, 0xAA0A0A1E);
            for (int i = 0; i <= N; i++) {
                double ang = Math.toRadians(135 + 270.0 * i / N);
                int ax = vcx + (int) Math.round(Math.cos(ang) * r), ay = vcy + (int) Math.round(Math.sin(ang) * r);
                boolean on = (float) i / N <= frac;
                int col = !on ? 0xFF2A2A44 : frac > 0.75f ? 0xFFFF3B3B : frac > 0.45f ? 0xFFFFC857 : 0xFF58FFB0;
                g.fill(ax - 1, ay - 1, ax + 2, ay + 2, col);
            }
            String sp = String.valueOf((int) ClientState.speed);
            g.pose().pushPose();
            g.pose().translate(vcx - f.width(sp), vcy - 10, 0);
            g.pose().scale(2f, 2f, 1f);
            g.drawString(f, sp, 0, 0, 0xFFFFFFFF, true);
            g.pose().popPose();
            g.drawString(f, "KM/H", vcx - f.width("KM/H") / 2, vcy + 12, 0xFFB9A8FF, true);
            String vn = ClientState.vehName;
            if (vn.length() > 18) vn = vn.substring(0, 18);
            g.drawString(f, vn, vcx - f.width(vn) / 2, vcy + r + 3, 0xFF9999BB, true);
        }
    }
}
