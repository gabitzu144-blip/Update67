package ro.mooncityx.client;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;

public class ClientHandler {
    public static void openScreen(String s) {
        Minecraft mc = Minecraft.getInstance();
        switch (s) {
            case "phone" -> mc.setScreen(new PhoneScreen());
            case "mdt" -> mc.setScreen(new MdtScreen());
            case "jbl" -> mc.setScreen(new JblScreen());
            default -> { }
        }
    }

    public static void handle(String t, CompoundTag d) {
        Minecraft mc = Minecraft.getInstance();
        switch (t) {
            case "sync" -> {
                ClientState.bal = d.getLong("bal");
                ClientState.iban = d.getString("iban");
                ClientState.job = d.getString("job");
                ClientState.xp = d.getInt("xp");
                ClientState.police = d.getBoolean("police");
                ClientState.wanted = d.getString("wanted");
                ClientState.contract = d.getCompound("contract");
                ClientState.zones = d.getList("zones", 10);
                ClientState.plots = d.getList("plots", 10);
            }
            case "wp" -> {
                if (d.contains("clear")) { ClientState.hasWp = false; return; }
                ClientState.hasWp = true;
                ClientState.wpx = d.getInt("x");
                ClientState.wpz = d.getInt("z");
                ClientState.wpName = d.getString("name");
            }
            case "inbox" -> {
                ListTag l = d.getList("l", 10);
                ClientState.inbox = new ArrayList<>();
                for (int i = 0; i < l.size(); i++) {
                    CompoundTag m = l.getCompound(i);
                    ClientState.inbox.add(m.getString("f") + ": " + m.getString("x"));
                }
            }
            case "msg" -> {
                if (mc.player != null) {
                    mc.player.displayClientMessage(Component.literal("\u00a7b[SMS] " + d.getString("from") + ": \u00a7f" + d.getString("text")), false);
                    mc.player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1f, 1.4f);
                }
            }
            case "ring" -> {
                ClientState.callState = "ringing";
                ClientState.callOther = d.getString("from");
                if (mc.player != null) {
                    mc.player.displayClientMessage(Component.literal("\u00a7a[Telefon] Apel de la " + d.getString("from") + " - deschide telefonul > Telefon"), false);
                    mc.player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1f, 0.6f);
                }
            }
            case "call" -> {
                ClientState.callState = d.getString("state");
                ClientState.callOther = d.getString("other");
            }
            case "mdt" -> {
                ListTag l = d.getList("l", 8);
                ClientState.mdt = new ArrayList<>();
                for (int i = 0; i < l.size(); i++) ClientState.mdt.add(l.getString(i));
            }
            case "open" -> openScreen(d.getString("s"));
            case "audio_play" -> Audio.play(d.getString("id"), d.getString("url"), d.getDouble("x"), d.getDouble("y"), d.getDouble("z"), d.getFloat("vol"));
            case "audio_pause" -> Audio.pause(d.getString("id"));
            case "audio_stop" -> Audio.stop(d.getString("id"));
            default -> { }
        }
    }
}
