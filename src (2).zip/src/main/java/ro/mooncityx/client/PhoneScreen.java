package ro.mooncityx.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import ro.mooncityx.Net;
import ro.mooncityx.Shop;
import ro.mooncityx.Util;

import java.util.List;

public class PhoneScreen extends Screen {
    static final int W = 230, H = 280;
    int L, T, tab = 0, page = 0;
    EditBox f1, f2;
    long hold = -1;
    String lastCall = "";

    static final String[][] JOBS = {
        {"padurar", "Padurar", "Taie busteni: $6 / trunchi"},
        {"fermier", "Fermier", "Culege recolta coapta: $10"},
        {"constructor", "Constructor", "Contract: pune blocuri langa santier"}
    };

    public PhoneScreen() { super(Component.literal("Telefon")); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void init() {
        L = (width - W) / 2;
        T = (height - H) / 2;
        Net.toServer("sync", new CompoundTag());
        rebuild();
    }

    Button btn(String s, int x, int y, int w, Runnable r) {
        Button b = Button.builder(Component.literal(s), bb -> r.run()).bounds(x, y, w, 18).build();
        addRenderableWidget(b);
        return b;
    }

    EditBox box(int x, int y, int w, String hint, int max) {
        EditBox b = new EditBox(font, x, y, w, 16, Component.literal(hint));
        b.setMaxLength(max);
        b.setHint(Component.literal(hint));
        addRenderableWidget(b);
        return b;
    }

    void go(int t) {
        tab = t;
        page = 0;
        if (t == 2) Net.toServer("inbox", new CompoundTag());
        rebuild();
    }

    void rebuild() {
        clearWidgets();
        f1 = null; f2 = null;
        switch (tab) {
            case 0 -> {
                String[] n = {"Banca", "Mesaje", "Telefon", "Magazin", "Joburi", "Waypoint"};
                for (int i = 0; i < 6; i++) {
                    final int t = i + 1;
                    btn(n[i], L + 12 + (i % 2) * 106, T + 50 + (i / 2) * 28, 100, () -> go(t));
                }
                if (ClientState.police) btn("MDT Politie", L + 12, T + 140, 206, () -> Minecraft.getInstance().setScreen(new MdtScreen()));
            }
            case 1 -> {
                f1 = box(L + 12, T + 84, W - 24, "IBAN destinatar", 24);
                f2 = box(L + 12, T + 120, W - 24, "Suma ($)", 10);
            }
            case 2 -> {
                f1 = box(L + 12, T + H - 76, W - 24, "Catre (nume)", 16);
                f2 = box(L + 12, T + H - 54, W - 24, "Mesaj", 100);
                btn("Trimite", L + W - 82, T + H - 26, 70, () -> {
                    if (f1.getValue().isBlank() || f2.getValue().isBlank()) return;
                    Net.toServer("msg", Util.tag("to", f1.getValue(), "text", f2.getValue()));
                    f2.setValue("");
                });
            }
            case 3 -> {
                String st = ClientState.callState;
                lastCall = st;
                if (st.equals("idle")) {
                    f1 = box(L + 12, T + 60, W - 24, "Nume jucator", 16);
                    btn("Suna", L + 12, T + 86, 100, () -> {
                        if (!f1.getValue().isBlank()) Net.toServer("call", Util.tag("name", f1.getValue()));
                    });
                } else if (st.equals("ringing")) {
                    btn("Raspunde", L + 12, T + 90, 100, () -> Net.toServer("call_accept", new CompoundTag()));
                    btn("Respinge", L + 118, T + 90, 100, () -> Net.toServer("call_end", new CompoundTag()));
                } else {
                    btn("Inchide apel", L + 12, T + 90, 206, () -> Net.toServer("call_end", new CompoundTag()));
                }
            }
            case 4 -> {
                List<Shop.Entry> l = Shop.LIST;
                int from = page * 6;
                for (int i = 0; i < 6 && from + i < l.size(); i++) {
                    final Shop.Entry e = l.get(from + i);
                    int y = T + 44 + i * 30;
                    btn("Cump $" + e.buy(), L + 92, y, 62, () -> Net.toServer("buy", Util.tag("id", e.id(), "qty", "1")));
                    btn("Vinde $" + e.sell(), L + 158, y, 62, () -> Net.toServer("sell", Util.tag("id", e.id(), "qty", "1")));
                }
                btn("<", L + 84, T + H - 26, 28, () -> { if (page > 0) { page--; rebuild(); } });
                btn(">", L + 118, T + H - 26, 28, () -> { if ((page + 1) * 6 < Shop.LIST.size()) { page++; rebuild(); } });
            }
            case 5 -> {
                for (int i = 0; i < 3; i++) {
                    final String key = JOBS[i][0];
                    btn(ClientState.job.equals(key) ? "ALES" : "Alege", L + W - 72, T + 56 + i * 46, 60, () -> Net.toServer("job", Util.tag("name", key)));
                }
                btn("Contract nou", L + 12, T + 200, 100, () -> Net.toServer("contract", new CompoundTag()));
                btn("Renunta job", L + 118, T + 200, 100, () -> Net.toServer("job", Util.tag("name", "none")));
            }
            case 6 -> {
                f1 = box(L + 12, T + 70, W - 24, "X", 8);
                f2 = box(L + 12, T + 94, W - 24, "Z", 8);
                btn("Seteaza", L + 12, T + 124, 100, () -> {
                    try {
                        ClientState.wpx = Integer.parseInt(f1.getValue().trim());
                        ClientState.wpz = Integer.parseInt(f2.getValue().trim());
                        ClientState.wpName = "Waypoint";
                        ClientState.hasWp = true;
                    } catch (NumberFormatException ignored) {}
                });
                btn("Sterge", L + 118, T + 124, 100, () -> ClientState.hasWp = false);
            }
            default -> { }
        }
        if (tab != 0) btn("Inapoi", L + 12, T + H - 26, 60, () -> go(0));
    }

    void doTransfer() {
        if (f1 == null || f2 == null || f1.getValue().isBlank() || f2.getValue().isBlank()) return;
        Net.toServer("transfer", Util.tag("iban", f1.getValue(), "amt", f2.getValue()));
        f2.setValue("");
    }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        if (tab == 1 && b == 0 && mx >= L + 12 && mx <= L + W - 12 && my >= T + H - 70 && my <= T + H - 46) {
            hold = System.currentTimeMillis();
            return true;
        }
        return super.mouseClicked(mx, my, b);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int b) {
        hold = -1;
        return super.mouseReleased(mx, my, b);
    }

    void text(GuiGraphics g, String s, int x, int y, int col) {
        g.drawString(font, font.plainSubstrByWidth(s, W - 20), x, y, col, false);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.fill(L - 5, T - 5, L + W + 5, T + H + 5, 0xFF3A2FB5);
        g.fill(L, T, L + W, T + H, 0xFF0A0B1F);
        g.drawCenteredString(font, "MoonCity Phone", L + W / 2, T + 8, 0xFFB9A8FF);
        String bal = "$" + Util.fmt(ClientState.bal);
        g.drawString(font, bal, L + W - 10 - font.width(bal), T + 22, 0xFF7CFFB0, false);

        if (tab == 3 && !lastCall.equals(ClientState.callState)) rebuild();

        switch (tab) {
            case 0 -> {
                text(g, "Alege o aplicatie", L + 12, T + 34, 0xFF9999BB);
                if (!ClientState.wanted.isEmpty()) text(g, "\u00a7cEsti URMARIT: " + ClientState.wanted, L + 12, T + 170, 0xFFFF5555);
            }
            case 1 -> {
                text(g, "IBAN-ul tau:", L + 12, T + 40, 0xFF9999BB);
                text(g, ClientState.iban, L + 12, T + 52, 0xFFB9A8FF);
                text(g, "Disponibil: $" + Util.fmt(ClientState.bal), L + 12, T + 64, 0xFFFFFFFF);
                int bx = L + 12, by = T + H - 70, bw = W - 24, bh = 24;
                g.fill(bx, by, bx + bw, by + bh, 0xFF1E1666);
                if (hold > 0) {
                    float pr = Math.min(1f, (System.currentTimeMillis() - hold) / 3000f);
                    g.fill(bx, by, bx + (int) (bw * pr), by + bh, 0xFF7A5CFF);
                    if (pr >= 1f) { hold = -1; doTransfer(); }
                }
                g.drawCenteredString(font, "TINE APASAT 3 SECUNDE", L + W / 2, by + 8, 0xFFFFFFFF);
                text(g, "Transferurile sunt instant si definitive.", L + 12, T + H - 40, 0xFF777799);
            }
            case 2 -> {
                int start = Math.max(0, ClientState.inbox.size() - 9);
                for (int i = start; i < ClientState.inbox.size(); i++)
                    text(g, ClientState.inbox.get(i), L + 12, T + 40 + (i - start) * 12, i % 2 == 0 ? 0xFFDDDDFF : 0xFFB9A8FF);
                if (ClientState.inbox.isEmpty()) text(g, "Niciun mesaj.", L + 12, T + 40, 0xFF777799);
            }
            case 3 -> {
                String st = ClientState.callState;
                String s = st.equals("idle") ? "Introdu numele jucatorului"
                    : st.equals("calling") ? "Se apeleaza " + ClientState.callOther + "..."
                    : st.equals("ringing") ? "Apel de la " + ClientState.callOther
                    : "In apel cu " + ClientState.callOther;
                text(g, s, L + 12, T + 40, 0xFFFFFFFF);
            }
            case 4 -> {
                List<Shop.Entry> l = Shop.LIST;
                int from = page * 6;
                for (int i = 0; i < 6 && from + i < l.size(); i++)
                    text(g, l.get(from + i).name(), L + 12, T + 49 + i * 30, 0xFFFFFFFF);
                text(g, "Magazin 24/7 - pagina " + (page + 1), L + 12, T + 32, 0xFF9999BB);
            }
            case 5 -> {
                int lvl = ClientState.xp / 50 + 1;
                text(g, "Job: " + ClientState.job + " | Nivel " + lvl + " (" + ClientState.xp + " XP)", L + 12, T + 32, 0xFF9999BB);
                for (int i = 0; i < 3; i++) {
                    g.drawString(font, JOBS[i][1], L + 12, T + 56 + i * 46, 0xFFFFFFFF, false);
                    g.drawString(font, font.plainSubstrByWidth(JOBS[i][2], W - 90), L + 12, T + 68 + i * 46, 0xFF9999BB, false);
                }
                if (ClientState.contract.contains("t")) {
                    int d = ClientState.contract.getInt("d"), t = ClientState.contract.getInt("t");
                    text(g, "Contract: " + d + "/" + t + " blocuri", L + 12, T + 184, 0xFFFFC857);
                    g.fill(L + 12, T + 226, L + W - 12, T + 234, 0xFF222244);
                    g.fill(L + 12, T + 226, L + 12 + (W - 24) * Math.min(d, t) / Math.max(1, t), T + 234, 0xFF58FFB0);
                }
            }
            case 6 -> {
                text(g, "Waypoint (apare pe minimap + linie)", L + 12, T + 40, 0xFF9999BB);
                if (ClientState.hasWp) {
                    Minecraft mc = Minecraft.getInstance();
                    double dx = ClientState.wpx - mc.player.getX(), dz = ClientState.wpz - mc.player.getZ();
                    double dist = Math.sqrt(dx * dx + dz * dz);
                    text(g, String.format("Activ: %d, %d  (%.2f km)", ClientState.wpx, ClientState.wpz, dist / 1000.0), L + 12, T + 52, 0xFFFFE066);
                }
            }
            default -> { }
        }
        super.render(g, mx, my, pt);
    }
}
