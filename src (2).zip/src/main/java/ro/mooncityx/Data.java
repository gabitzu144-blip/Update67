package ro.mooncityx;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.Random;
import java.util.UUID;

public class Data extends SavedData {
    static final Random RND = new Random();
    public CompoundTag r = new CompoundTag();

    public static Data get(MinecraftServer s) {
        return s.overworld().getDataStorage().computeIfAbsent(Data::load, Data::new, "mooncityx");
    }

    public static Data load(CompoundTag t) {
        Data d = new Data();
        d.r = t.getCompound("r");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.put("r", r);
        return t;
    }

    public CompoundTag sub(String k) {
        if (!r.contains(k, 10)) r.put(k, new CompoundTag());
        setDirty();
        return r.getCompound(k);
    }

    public ListTag list(String k) {
        if (!r.contains(k, 9)) r.put(k, new ListTag());
        setDirty();
        return r.getList(k, 10);
    }

    // ---------- banca ----------
    public void touch(ServerPlayer p) {
        String id = p.getUUID().toString();
        sub("names").putString(id, p.getGameProfile().getName());
        CompoundTag ib = sub("iban");
        if (!ib.contains(id)) {
            String s;
            do { s = "ROXX-IBAN-" + (100000000 + RND.nextInt(900000000)); } while (ibanOwner(s) != null);
            ib.putString(id, s);
            sub("bal").putLong(id, 1000L);
        }
    }

    public UUID ibanOwner(String iban) {
        CompoundTag ib = sub("iban");
        for (String k : ib.getAllKeys()) if (ib.getString(k).equals(iban)) return UUID.fromString(k);
        return null;
    }

    public UUID uuidByName(String n) {
        CompoundTag nm = sub("names");
        for (String k : nm.getAllKeys()) if (nm.getString(k).equalsIgnoreCase(n)) return UUID.fromString(k);
        return null;
    }

    public String nameOf(String uuid) { return sub("names").getString(uuid); }
    public String nameOf(UUID u) { return nameOf(u.toString()); }

    public long bal(UUID u) { return sub("bal").getLong(u.toString()); }
    public void add(UUID u, long a) { sub("bal").putLong(u.toString(), bal(u) + a); }
    public boolean take(UUID u, long a) {
        if (a < 0 || bal(u) < a) return false;
        sub("bal").putLong(u.toString(), bal(u) - a);
        return true;
    }

    // ---------- joburi ----------
    public String job(UUID u) {
        String j = sub("job").getString(u.toString());
        return j.isEmpty() ? "none" : j;
    }
    public int xp(UUID u) { return sub("xp").getInt(u.toString()); }

    // ---------- ploturi / zone ----------
    static boolean in(CompoundTag c, int x, int z) {
        return x >= c.getInt("x1") && x <= c.getInt("x2") && z >= c.getInt("z1") && z <= c.getInt("z2");
    }

    public CompoundTag plotAt(int x, int z) {
        for (Tag t : list("plots")) if (in((CompoundTag) t, x, z)) return (CompoundTag) t;
        return null;
    }

    public CompoundTag zoneAt(int x, int z, String type) {
        for (Tag t : list("zones")) {
            CompoundTag c = (CompoundTag) t;
            if (c.getString("t").equals(type) && in(c, x, z)) return c;
        }
        return null;
    }

    public boolean isMember(CompoundTag plot, UUID u) {
        String s = u.toString();
        if (s.equals(plot.getString("o"))) return true;
        for (Tag t : plot.getList("m", 8)) if (t.getAsString().equals(s)) return true;
        return false;
    }

    // ---------- mafii ----------
    public ListTag mafia(String name) {
        CompoundTag m = sub("mafia");
        if (!m.contains(name, 9)) m.put(name, new ListTag());
        return m.getList(name, 8);
    }

    public String mafiaOf(UUID u) {
        CompoundTag m = sub("mafia");
        for (String k : m.getAllKeys())
            for (Tag t : m.getList(k, 8)) if (t.getAsString().equals(u.toString())) return k;
        return "-";
    }
}
