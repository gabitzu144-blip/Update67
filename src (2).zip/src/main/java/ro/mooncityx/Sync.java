package ro.mooncityx;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;

public class Sync {
    public static void send(ServerPlayer p) {
        Data D = Data.get(p.server);
        String id = p.getUUID().toString();
        CompoundTag t = new CompoundTag();
        t.putLong("bal", D.bal(p.getUUID()));
        t.putString("iban", D.sub("iban").getString(id));
        t.putString("job", D.job(p.getUUID()));
        t.putInt("xp", D.xp(p.getUUID()));
        t.putBoolean("police", Actions.isPolice(p));
        t.putString("wanted", D.sub("wanted").getString(id));
        t.put("contract", D.sub("contract").getCompound(id).copy());
        t.put("zones", D.list("zones").copy());
        ListTag pl = new ListTag();
        for (Tag x : D.list("plots")) {
            CompoundTag q = ((CompoundTag) x).copy();
            String o = q.getString("o");
            q.putString("on", o.isEmpty() ? "" : D.nameOf(o));
            q.putBoolean("mine", o.equals(id));
            q.remove("m");
            pl.add(q);
        }
        t.put("plots", pl);
        Net.toPlayer(p, "sync", t);
    }

    public static void waypoint(ServerPlayer p, int x, int z, String name) {
        CompoundTag t = Util.tag("name", name);
        t.putInt("x", x);
        t.putInt("z", z);
        Net.toPlayer(p, "wp", t);
    }
}
