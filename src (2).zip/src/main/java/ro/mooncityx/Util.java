package ro.mooncityx;

import net.minecraft.nbt.CompoundTag;
import java.util.regex.Pattern;

public class Util {
    public static final Pattern YT = Pattern.compile("^https://(www\\.|m\\.|music\\.)?(youtube\\.com|youtu\\.be)/[A-Za-z0-9_\\-./?=&%]{1,200}$");

    public static CompoundTag tag(String... kv) {
        CompoundTag t = new CompoundTag();
        for (int i = 0; i + 1 < kv.length; i += 2) t.putString(kv[i], kv[i + 1]);
        return t;
    }

    public static String fmt(long v) { return String.format("%,d", v); }
}
