package ro.mooncityx;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;

public class Protect {
    /** @param city daca true, zonele "city" fara plot sunt blocate */
    public static boolean canBuild(ServerPlayer p, BlockPos pos, boolean city) {
        if (p.hasPermissions(2) && p.isCreative()) return true;
        Data D = Data.get(p.server);
        int x = pos.getX(), z = pos.getZ();
        CompoundTag pl = D.plotAt(x, z);
        if (pl != null) return D.isMember(pl, p.getUUID());
        if (city && D.zoneAt(x, z, "city") != null) return false;
        return true;
    }
}
