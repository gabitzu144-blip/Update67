package ro.mooncityx;

import java.util.List;

public class Shop {
    public record Entry(String id, String name, int buy, int sell) {}

    public static final List<Entry> LIST = List.of(
        new Entry("minecraft:bread", "Paine", 8, 3),
        new Entry("minecraft:apple", "Mar", 5, 2),
        new Entry("minecraft:cooked_beef", "Friptura", 12, 5),
        new Entry("minecraft:wheat", "Grau", 6, 2),
        new Entry("minecraft:coal", "Carbune", 10, 3),
        new Entry("minecraft:iron_ingot", "Lingou fier", 40, 15),
        new Entry("minecraft:gold_ingot", "Lingou aur", 70, 25),
        new Entry("minecraft:diamond", "Diamant", 300, 120),
        new Entry("minecraft:oak_log", "Buturuga", 8, 3),
        new Entry("minecraft:cobblestone", "Piatra", 3, 1),
        new Entry("minecraft:torch", "Torta", 4, 1),
        new Entry("minecraft:bucket", "Galeata", 60, 20)
    );

    public static Entry find(String id) {
        for (Entry e : LIST) if (e.id().equals(id)) return e;
        return null;
    }
}
