package ro.mooncityx;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class Net {
    static final String P = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(Main.ID, "main"), () -> P, P::equals, P::equals);
    static boolean done = false;

    public static void init() {
        if (done) return;
        done = true;
        CH.registerMessage(0, Act.class, Act::enc, Act::dec, Act::handle);
        CH.registerMessage(1, Ui.class, Ui::enc, Ui::dec, Ui::handle);
    }

    public static void toServer(String a, CompoundTag d) { CH.sendToServer(new Act(a, d)); }
    public static void toPlayer(ServerPlayer p, String t, CompoundTag d) { CH.send(PacketDistributor.PLAYER.with(() -> p), new Ui(t, d)); }
    public static void toAll(String t, CompoundTag d) { CH.send(PacketDistributor.ALL.noArg(), new Ui(t, d)); }

    /** client -> server */
    public static class Act {
        final String a; final CompoundTag d;
        public Act(String a, CompoundTag d) { this.a = a; this.d = d; }
        void enc(FriendlyByteBuf b) { b.writeUtf(a, 32); b.writeNbt(d); }
        static Act dec(FriendlyByteBuf b) {
            String a = b.readUtf(32);
            CompoundTag d = b.readNbt();
            return new Act(a, d == null ? new CompoundTag() : d);
        }
        static void handle(Act m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> {
                ServerPlayer p = c.getSender();
                if (p != null) Actions.handle(p, m.a, m.d);
            });
            c.setPacketHandled(true);
        }
    }

    /** server -> client */
    public static class Ui {
        final String t; final CompoundTag d;
        public Ui(String t, CompoundTag d) { this.t = t; this.d = d; }
        void enc(FriendlyByteBuf b) { b.writeUtf(t, 32); b.writeNbt(d); }
        static Ui dec(FriendlyByteBuf b) {
            String t = b.readUtf(32);
            CompoundTag d = b.readNbt();
            return new Ui(t, d == null ? new CompoundTag() : d);
        }
        static void handle(Ui m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ro.mooncityx.client.ClientHandler.handle(m.t, m.d)));
            c.setPacketHandled(true);
        }
    }
}
