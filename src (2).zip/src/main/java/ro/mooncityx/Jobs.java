package ro.mooncityx;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;

public class Jobs {
    static void addXp(Data D, ServerPlayer p, int n) {
        String id = p.getUUID().toString();
        D.sub("xp").putInt(id, D.xp(p.getUUID()) + n);
    }

    public static void onBreak(ServerPlayer p, BlockState s) {
        Data D = Data.get(p.server);
        String j = D.job(p.getUUID());
        long pay = 0;
        if (j.equals("padurar") && s.is(BlockTags.LOGS)) pay = 6;
        else if (j.equals("fermier") && s.getBlock() instanceof CropBlock c && c.isMaxAge(s)) pay = 10;
        if (pay > 0) {
            addXp(D, p, 1);
            int lvl = D.xp(p.getUUID()) / 50 + 1;
            pay += lvl - 1;
            D.add(p.getUUID(), pay);
            p.displayClientMessage(Component.literal("\u00a7a+$" + pay + " \u00a77(nivel " + lvl + ")"), true);
        }
    }

    public static void startContract(ServerPlayer p) {
        Data D = Data.get(p.server);
        String id = p.getUUID().toString();
        if (!D.job(p.getUUID()).equals("constructor")) {
            p.sendSystemMessage(Component.literal("\u00a7cNu esti constructor."));
            return;
        }
        int lvl = D.xp(p.getUUID()) / 50 + 1;
        CompoundTag c = new CompoundTag();
        c.putInt("ox", p.blockPosition().getX());
        c.putInt("oy", p.blockPosition().getY());
        c.putInt("oz", p.blockPosition().getZ());
        c.putInt("d", 0);
        c.putInt("t", 40 + 20 * lvl);
        D.sub("contract").put(id, c);
        Sync.waypoint(p, c.getInt("ox"), c.getInt("oz"), "Santier");
        p.sendSystemMessage(Component.literal("\u00a7aContract nou: pune " + c.getInt("t") + " blocuri in raza de 16 blocuri de aici."));
        Sync.send(p);
    }

    public static void onPlace(ServerPlayer p, BlockPos pos) {
        Data D = Data.get(p.server);
        String id = p.getUUID().toString();
        CompoundTag all = D.sub("contract");
        if (!all.contains(id, 10)) return;
        CompoundTag c = all.getCompound(id);
        int dx = pos.getX() - c.getInt("ox"), dz = pos.getZ() - c.getInt("oz");
        if (dx * dx + dz * dz > 256) return;
        c.putInt("d", c.getInt("d") + 1);
        int left = c.getInt("t") - c.getInt("d");
        if (left <= 0) {
            long pay = 300 + 3L * c.getInt("t");
            D.add(p.getUUID(), pay);
            addXp(D, p, 10);
            all.remove(id);
            p.sendSystemMessage(Component.literal("\u00a7aContract terminat! +$" + pay));
            Sync.send(p);
        } else {
            p.displayClientMessage(Component.literal("\u00a7eContract: mai ai " + left + " blocuri"), true);
            if (left % 5 == 0) Sync.send(p);
        }
    }
}
