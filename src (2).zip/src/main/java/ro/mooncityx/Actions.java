package ro.mooncityx;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;

public class Actions {
    static final Map<UUID, UUID> CALLS = new HashMap<>();   // caller -> target (suna)
    static final Map<UUID, UUID> ACTIVE = new HashMap<>();  // in apel (ambele sensuri)
    static final Map<UUID, Long> JBL_CD = new HashMap<>();

    public static boolean isPolice(ServerPlayer p) {
        return p.hasPermissions(2) || Data.get(p.server).sub("police").getBoolean(p.getUUID().toString());
    }

    static boolean has(ServerPlayer p, Item it) {
        for (ItemStack s : p.getInventory().items) if (s.is(it)) return true;
        return p.getOffhandItem().is(it);
    }

    static String str(CompoundTag d, String k, int max) {
        String s = d.getString(k).trim();
        return s.length() > max ? s.substring(0, max) : s;
    }

    static long num(CompoundTag d, String k) {
        try { return Long.parseLong(d.getString(k).trim()); } catch (Exception e) { return -1; }
    }

    static void say(ServerPlayer p, String m) { p.sendSystemMessage(Component.literal(m)); }

    static void mdt(ServerPlayer p, List<String> lines) {
        CompoundTag t = new CompoundTag();
        ListTag l = new ListTag();
        for (String s : lines) l.add(StringTag.valueOf(s));
        t.put("l", l);
        Net.toPlayer(p, "mdt", t);
    }

    static void callState(ServerPlayer p, String state, String other) {
        Net.toPlayer(p, "call", Util.tag("state", state, "other", other));
    }

    public static void handle(ServerPlayer p, String a, CompoundTag d) {
        Data D = Data.get(p.server);
        UUID me = p.getUUID();
        D.touch(p);
        switch (a) {
            case "sync" -> Sync.send(p);

            case "transfer" -> {
                if (!has(p, Main.PHONE.get())) return;
                String iban = str(d, "iban", 24).toUpperCase();
                long amt = num(d, "amt");
                if (amt <= 0 || amt > 1_000_000_000L) { say(p, "\u00a7cSuma invalida."); return; }
                UUID to = D.ibanOwner(iban);
                if (to == null) { say(p, "\u00a7cIBAN inexistent."); return; }
                if (to.equals(me)) { say(p, "\u00a7cNu iti poti trimite singur."); return; }
                if (!D.take(me, amt)) { say(p, "\u00a7cFonduri insuficiente."); return; }
                D.add(to, amt);
                say(p, "\u00a7aTransfer $" + Util.fmt(amt) + " catre " + D.nameOf(to));
                ServerPlayer tp = p.server.getPlayerList().getPlayer(to);
                if (tp != null) { say(tp, "\u00a7a[Banca] Ai primit $" + Util.fmt(amt) + " de la " + p.getGameProfile().getName()); Sync.send(tp); }
                Sync.send(p);
            }

            case "inbox" -> {
                if (!has(p, Main.PHONE.get())) return;
                CompoundTag ib = D.sub("inbox");
                ListTag l = ib.contains(me.toString(), 9) ? ib.getList(me.toString(), 10) : new ListTag();
                CompoundTag t = new CompoundTag();
                t.put("l", l.copy());
                Net.toPlayer(p, "inbox", t);
            }

            case "msg" -> {
                if (!has(p, Main.PHONE.get())) return;
                String to = str(d, "to", 16), text = str(d, "text", 100);
                UUID tu = D.uuidByName(to);
                if (tu == null || text.isEmpty()) { say(p, "\u00a7cDestinatar sau mesaj invalid."); return; }
                String myName = p.getGameProfile().getName();
                store(D, tu, myName, text);
                store(D, me, "Tu -> " + D.nameOf(tu), text);
                ServerPlayer tp = p.server.getPlayerList().getPlayer(tu);
                if (tp != null) Net.toPlayer(tp, "msg", Util.tag("from", myName, "text", text));
                Actions.handle(p, "inbox", new CompoundTag());
            }

            case "call" -> {
                if (!has(p, Main.PHONE.get())) return;
                UUID tu = D.uuidByName(str(d, "name", 16));
                ServerPlayer tp = tu == null ? null : p.server.getPlayerList().getPlayer(tu);
                if (tp == null || tp == p) { say(p, "\u00a7cJucatorul nu e online."); return; }
                if (ACTIVE.containsKey(tu) || ACTIVE.containsKey(me)) { say(p, "\u00a7cOcupat."); return; }
                CALLS.put(me, tu);
                Net.toPlayer(tp, "ring", Util.tag("from", p.getGameProfile().getName()));
                callState(p, "calling", tp.getGameProfile().getName());
            }

            case "call_accept" -> {
                UUID caller = null;
                for (Map.Entry<UUID, UUID> e : CALLS.entrySet()) if (e.getValue().equals(me)) caller = e.getKey();
                ServerPlayer cp = caller == null ? null : p.server.getPlayerList().getPlayer(caller);
                if (cp == null) { callState(p, "idle", ""); return; }
                CALLS.remove(caller);
                ACTIVE.put(me, caller);
                ACTIVE.put(caller, me);
                callState(p, "active", cp.getGameProfile().getName());
                callState(cp, "active", p.getGameProfile().getName());
            }

            case "call_end" -> {
                UUID other = ACTIVE.remove(me);
                if (other != null) {
                    ACTIVE.remove(other);
                    ServerPlayer op = p.server.getPlayerList().getPlayer(other);
                    if (op != null) callState(op, "idle", "");
                }
                UUID tgt = CALLS.remove(me);
                if (tgt != null) {
                    ServerPlayer tp = p.server.getPlayerList().getPlayer(tgt);
                    if (tp != null) callState(tp, "idle", "");
                }
                List<UUID> callers = new ArrayList<>();
                for (Map.Entry<UUID, UUID> e : CALLS.entrySet()) if (e.getValue().equals(me)) callers.add(e.getKey());
                for (UUID c : callers) {
                    CALLS.remove(c);
                    ServerPlayer cp = p.server.getPlayerList().getPlayer(c);
                    if (cp != null) callState(cp, "idle", "");
                }
                callState(p, "idle", "");
            }

            case "buy" -> {
                if (!has(p, Main.PHONE.get())) return;
                Shop.Entry e = Shop.find(str(d, "id", 64));
                long q = Math.max(1, Math.min(64, num(d, "qty")));
                if (e == null) return;
                long cost = (long) e.buy() * q;
                Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(e.id()));
                if (it == null) return;
                if (!D.take(me, cost)) { say(p, "\u00a7cFonduri insuficiente."); return; }
                ItemStack st = new ItemStack(it, (int) q);
                if (!p.getInventory().add(st)) p.drop(st, false);
                p.displayClientMessage(Component.literal("\u00a7a-$" + cost + " " + e.name()), true);
                Sync.send(p);
            }

            case "sell" -> {
                if (!has(p, Main.PHONE.get())) return;
                Shop.Entry e = Shop.find(str(d, "id", 64));
                long q = Math.max(1, Math.min(64, num(d, "qty")));
                if (e == null) return;
                Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(e.id()));
                if (it == null) return;
                int left = (int) q, sold = 0;
                for (ItemStack s : p.getInventory().items) {
                    if (left > 0 && s.is(it)) {
                        int n = Math.min(left, s.getCount());
                        s.shrink(n);
                        left -= n;
                        sold += n;
                    }
                }
                if (sold == 0) { say(p, "\u00a7cNu ai " + e.name() + "."); return; }
                long pay = (long) e.sell() * sold;
                D.add(me, pay);
                p.displayClientMessage(Component.literal("\u00a7a+$" + pay + " " + e.name()), true);
                Sync.send(p);
            }

            case "job" -> {
                String n = str(d, "name", 16);
                if (n.equals("padurar") || n.equals("fermier") || n.equals("constructor")) {
                    D.sub("job").putString(me.toString(), n);
                } else {
                    D.sub("job").remove(me.toString());
                    D.sub("contract").remove(me.toString());
                }
                Sync.send(p);
            }

            case "contract" -> Jobs.startContract(p);

            case "mdt_search" -> {
                if (!isPolice(p)) return;
                UUID u = D.uuidByName(str(d, "name", 16));
                List<String> l = new ArrayList<>();
                if (u == null) l.add("Jucator inexistent.");
                else {
                    String w = D.sub("wanted").getString(u.toString());
                    l.add("Nume: " + D.nameOf(u));
                    l.add("Job: " + D.job(u));
                    l.add("Wanted: " + (w.isEmpty() ? "NU" : "DA - " + w));
                    l.add("Mafie: " + D.mafiaOf(u));
                    l.add("Amenzi totale: $" + Util.fmt(D.sub("fines").getLong(u.toString())));
                }
                mdt(p, l);
            }

            case "mdt_wanted" -> {
                if (!isPolice(p)) return;
                UUID u = D.uuidByName(str(d, "name", 16));
                if (u == null) { mdt(p, List.of("Jucator inexistent.")); return; }
                String reason = str(d, "reason", 60);
                if (reason.isEmpty()) { D.sub("wanted").remove(u.toString()); mdt(p, List.of("Wanted sters pentru " + D.nameOf(u))); }
                else { D.sub("wanted").putString(u.toString(), reason); mdt(p, List.of("Wanted setat: " + D.nameOf(u) + " - " + reason)); }
                ServerPlayer tp = p.server.getPlayerList().getPlayer(u);
                if (tp != null) Sync.send(tp);
            }

            case "mdt_fine" -> {
                if (!isPolice(p)) return;
                UUID u = D.uuidByName(str(d, "name", 16));
                long amt = num(d, "amt");
                if (u == null || amt <= 0 || amt > 100000) { mdt(p, List.of("Date invalide (suma 1-100000).")); return; }
                long paid = Math.min(amt, D.bal(u));
                D.take(u, paid);
                CompoundTag f = D.sub("fines");
                f.putLong(u.toString(), f.getLong(u.toString()) + paid);
                mdt(p, List.of("Amenda $" + Util.fmt(paid) + " aplicata lui " + D.nameOf(u) + " (" + str(d, "reason", 40) + ")"));
                ServerPlayer tp = p.server.getPlayerList().getPlayer(u);
                if (tp != null) { say(tp, "\u00a7c[Politia] Amenda $" + Util.fmt(paid) + ": " + str(d, "reason", 40)); Sync.send(tp); }
            }

            case "mdt_mafias" -> {
                if (!isPolice(p)) return;
                CompoundTag m = D.sub("mafia");
                List<String> l = new ArrayList<>();
                for (String k : m.getAllKeys()) {
                    StringBuilder sb = new StringBuilder(k + ": ");
                    for (Tag t : m.getList(k, 8)) sb.append(D.nameOf(t.getAsString())).append(", ");
                    l.add(sb.toString());
                }
                if (l.isEmpty()) l.add("Nu exista mafii. (/mafia create <nume>)");
                mdt(p, l);
            }

            case "jbl_play" -> {
                if (!has(p, Main.JBL.get())) return;
                long now = System.currentTimeMillis();
                Long last = JBL_CD.get(me);
                if (last != null && now - last < 3000) return;
                JBL_CD.put(me, now);
                String url = str(d, "url", 200);
                if (!Util.YT.matcher(url).matches()) { say(p, "\u00a7cLink YouTube invalid."); return; }
                float vol = 0.5f;
                try { vol = Math.max(0f, Math.min(1f, Float.parseFloat(d.getString("vol")))); } catch (Exception ignored) {}
                CompoundTag t = Util.tag("id", me.toString(), "url", url);
                t.putDouble("x", p.getX());
                t.putDouble("y", p.getY());
                t.putDouble("z", p.getZ());
                t.putFloat("vol", vol);
                Net.toAll("audio_play", t);
            }

            case "jbl_pause" -> { if (has(p, Main.JBL.get())) Net.toAll("audio_pause", Util.tag("id", me.toString())); }
            case "jbl_stop" -> { if (has(p, Main.JBL.get())) Net.toAll("audio_stop", Util.tag("id", me.toString())); }
            default -> { }
        }
    }

    static void store(Data D, UUID to, String from, String text) {
        CompoundTag ib = D.sub("inbox");
        String id = to.toString();
        if (!ib.contains(id, 9)) ib.put(id, new ListTag());
        ListTag l = ib.getList(id, 10);
        l.add(Util.tag("f", from, "x", text));
        while (l.size() > 40) l.remove(0);
    }
}
