package ro.mooncityx;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import ro.mooncityx.client.ClientHandler;

public class PhoneItem extends Item {
    public PhoneItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
        if (l.isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHandler.openScreen("phone"));
        } else if (p instanceof ServerPlayer sp) {
            Data.get(sp.server).touch(sp);
            Sync.send(sp);
        }
        return InteractionResultHolder.sidedSuccess(p.getItemInHand(h), l.isClientSide);
    }
}
